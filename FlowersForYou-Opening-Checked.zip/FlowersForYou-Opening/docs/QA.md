# Opening QA - actual verification

## Results

- 9 Node.js tests passed: canonical text equality, all paragraphs retained,
  content hash, continuation after the instruction, chapter indexes, durations,
  timing of long paragraphs, final holds and garden entry URL.
- 8 Python tests passed: HTML IDs/local asset paths, original text hash, WAV
  format, no bundled fonts, app registration injection, app factory support,
  ambiguous-app rejection and non-destructive installation with a real backup.
- 19 Chromium UI scenarios passed using the native-animation branch in memory.
- All 135 passages were checked for horizontal overflow and lower-edge overlap
  at 320x740, 390x844, 768x1024, 1440x960, 1920x1080 and 844x390 viewports.
- An accelerated automatic playback visited all indices 0 through 134 in order,
  then ended. This checks sequence completeness, not comfortable reading at 100x.
- MP3 decoding/playback through Web Audio succeeded after a click. Play/pause,
  mute, volume and tab-hidden pause were tested.
- The preview HTTP server returned 200 for the HTML, JS, CSS, MP3 and story text.
- JavaScript and Python syntax checks passed.

Full data: browser-test-results.json, browser-test-log.txt,
python-test-results.txt, js-test-results.txt, http-test-results.json.

## Frame measurement

The latest 4-second sample during native playback in desktop Chromium headless
recorded 240 frame callbacks. Mean interval was approximately 16.63 ms, median
16.70 ms and p95 16.90 ms, corresponding to about 60.1 callbacks/second.

This is **not** a GPU-presented-frame benchmark and not a guaranteed 60 fps on
phones. It measures callback cadence in the test browser. Real presentation,
thermal throttling, low-power modes, browser scheduling and screen refresh rate
must be checked on the destination PC and iPhone. The implementation aims for
60 fps with opacity/transform animation and only one active paragraph.

## What was not verified

GSAP could not be downloaded in the build environment, so its actual library
execution was not tested. The GSAP branch is source-complete and syntax-checked;
the UI tests ran real browser-native Web Animations, not a mocked GSAP library.
The footer labels that branch explicitly.

Flask is not installed in the build environment. Route registration code was
syntax-checked; integration patching was tested on temporary projects. Actual
Flask routing, app-specific integrations and deployment still require testing
in the user's Codespace. The standalone standard-library HTTP server was tested.

Browser navigation to localhost was blocked by the environment's browser policy.
For UI checks the actual HTML/CSS/JS were bundled in memory, with local assets
embedded. This does not validate network module loading or CDN behavior. There
was no physical iPhone, Safari, Firefox, screen-reader audit or production hosting
verification. No claim of a completely bug-free implementation is made.

## Screenshots

cover-desktop.png, story-desktop.png, cover-mobile.png, story-mobile.png and
ending-mobile.png are actual Chromium screenshots of the native opening.
No generated mockup image was used as evidence. The images use system-font
fallbacks because external fonts were unavailable; the online HTML requests
Instrument Serif + Inter and may have different font metrics.

## Verify the actual GSAP path in Codespaces or on PC

1. Run tools/install_opening_gsap.py. Confirm the real gsap.min.js file exists.
2. Run the opening server and check that the footer begins with GSAP.
3. Install Playwright/Chromium, then run:

```bash
python3 tests/browser_opening.py --url http://127.0.0.1:5001/opening --require-gsap
```

The --require-gsap option rejects native fallback instead of calling it success.
Test original and long paragraphs, pause/resume, chapter changes, full letter,
mute, text speed, tab switching, end card and link to the real 3D garden.
