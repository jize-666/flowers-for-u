# Source and assets

Original narrative: all English paragraphs supplied by the user, 135 paragraphs,
1,053 whitespace-delimited words, 6,238 Unicode characters. It is not rewritten
or shortened. Added chapter labels and cover/end-card text are outside it.

Paper: procedural 512x512 WEBP, created by tools/build_opening_assets.py.
Grain: procedural 128x128 PNG, static in the interface.
Botanical mark: editable local SVG.
Music: newly synthesized original 64-second pad and soft-key composition.
Formats: MP3 for playback, stereo PCM WAV for editing. No commercial song,
external sample pack, speech, cloned voice or recorded piano is included.

GSAP: external dependency, pinned 3.13.0. Not downloaded during this build.
The installer downloads the official npm CDN build and retains its license
header. Its standard license applies separately to the library.
https://gsap.com/standard-license/

Fonts: HTML requests Instrument Serif and Inter through Google Fonts. No font
file is distributed. Offline preview uses system fonts.

The new application source, generated textures, SVG and synthesized audio may
be edited and used for this project. The user's narrative remains the user's
content. This file does not grant public sharing rights to private story details.
