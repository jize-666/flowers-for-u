from pathlib import Path
import argparse
import json
import math
import os
import sys
import time
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from build_offline_preview import build


def run(url=None, require_gsap=False):
    results = []
    errors = []
    def passed(name):
        results.append({'test': name, 'result': 'passed'})
        print('PASS', name, flush=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH', '/usr/bin/chromium'),
                                    headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 960})
        page.on('pageerror', lambda e: errors.append(str(e)))
        def load():
            if url:
                page.goto(url + ('&' if '?' in url else '?') + 'debug=1', wait_until='domcontentloaded')
            else:
                page.set_content(build(True), wait_until='load')
            page.wait_for_function('window.__OPENING__ !== undefined', timeout=25000)
        load()
        state = page.evaluate('window.__OPENING__.getState()')
        if require_gsap:
            assert state['engine'] == 'gsap', 'The test requires real GSAP, not native fallback.'
        assert state['state'] == 'cover' and state['audio'] == 'not-started'
        passed('Cover does not start text or audio automatically')
        original = (ROOT / 'docs/synopsis-original.txt').read_text().rstrip('\n')
        transcript = page.locator('#transcript-content p').all_text_contents()
        assert '\n\n'.join(transcript) == original
        passed('All 135 paragraphs and punctuation match the canonical synopsis in transcript')
        page.click('#read-all')
        assert page.locator('#transcript-dialog').evaluate('(el) => el.open')
        page.keyboard.press('Escape')
        assert not page.locator('#transcript-dialog').evaluate('(el) => el.open')
        assert page.evaluate('window.__OPENING__.getState().state') == 'cover'
        passed('Full letter opens and closes before playback without starting story')
        page.screenshot(path=str(ROOT / 'docs/cover-desktop.png'), full_page=True)
        page.click('#begin-opening')
        page.wait_for_timeout(1800)
        assert page.evaluate('window.__OPENING__.getState().index') == 0
        assert page.locator('.passage-word').evaluate_all('(els) => els.every(e => Number(getComputedStyle(e).opacity) > .98)')
        passed('Words fade into view in the first passage')
        page.wait_for_function('window.__OPENING__.getState().audioSource === true', timeout=10000)
        assert page.evaluate('window.__OPENING__.getState().audio') == 'running'
        passed('User click starts the supplied MP3 through Web Audio')
        page.screenshot(path=str(ROOT / 'docs/story-desktop.png'), full_page=True)
        page.click('#play-pause')
        progress = page.evaluate('window.__OPENING__.player.timeline.time()')
        page.wait_for_timeout(300)
        assert abs(page.evaluate('window.__OPENING__.player.timeline.time()') - progress) < .04
        assert not page.evaluate('window.__OPENING__.getState().audioSource')
        passed('Pause freezes timeline and stops audio source')
        page.click('#next-passage')
        assert page.evaluate('window.__OPENING__.getState().index') == 1
        assert page.evaluate('window.__OPENING__.getState().state') == 'paused'
        page.click('#previous-passage')
        assert page.evaluate('window.__OPENING__.getState().index') == 0
        passed('Next and previous preserve paused state and show readable text')
        page.select_option('#chapter-select', '22')
        assert page.evaluate('window.__OPENING__.getState().index') == 22
        passed('Chapter selection seeks to the correct unabridged passage')
        page.select_option('#reading-speed', '1.5')
        assert page.evaluate('window.__OPENING__.player.timeline.timeScale()') == 1.5
        passed('Playback rate changes the text timeline')
        page.click('#play-pause')
        page.wait_for_timeout(120)
        page.click('#read-all')
        assert page.evaluate('window.__OPENING__.getState().state') == 'paused'
        page.click('#close-transcript')
        page.wait_for_function("window.__OPENING__.getState().state === 'playing'")
        passed('Transcript suspends and restores an ongoing story')
        page.click('#audio-toggle')
        assert not page.evaluate('window.__OPENING__.player.audio.enabled')
        assert not page.evaluate('window.__OPENING__.getState().audioSource')
        page.locator('#audio-volume').fill('18')
        assert abs(page.evaluate('window.__OPENING__.player.audio.volume') - .18) < .0001
        passed('Mute and volume controls update Web Audio state')
        page.evaluate("Object.defineProperty(document, 'hidden', { configurable: true, value: true }); document.dispatchEvent(new Event('visibilitychange'))")
        assert page.evaluate('window.__OPENING__.getState().state') == 'paused'
        page.evaluate("delete document.hidden")
        passed('Background-tab event pauses the story')
        page.evaluate('window.__OPENING__.player.showCue(0, true)')
        page.wait_for_function('window.__OPENING__.getState().index === 1', timeout=12000)
        passed('Natural timeline completion advances to the next passage')
        page.evaluate('window.__OPENING__.player.pause()')
        clipped = []
        for width, height in [(320, 740), (390, 844), (768, 1024), (1440, 960), (1920, 1080), (844, 390)]:
            page.set_viewport_size({'width': width, 'height': height})
            details = page.evaluate('''() => {
              const failures = [];
              for (let i=0; i<135; i++) {
                window.__OPENING__.player.showCue(i, false);
                const box=document.querySelector('#passage').getBoundingClientRect();
                const paper=document.querySelector('.opening-paper').getBoundingClientRect();
                const footer=document.querySelector('.paper-footer').getBoundingClientRect();
                if (box.left < paper.left || box.right > paper.right || box.bottom > footer.top - 4)
                  failures.push({i, bottom:box.bottom, footer:footer.top});
              }
              return {failures, width:document.documentElement.scrollWidth, inner:innerWidth};
            }''')
            if details['failures'] or details['width'] > details['inner']:
                clipped.append({'viewport': [width, height], **details})
        assert not clipped, clipped
        passed('All 135 passages fit at six viewport sizes with no horizontal overflow')
        page.set_viewport_size({'width': 390, 'height': 844})
        page.evaluate('window.__OPENING__.player.showCue(2, false)')
        page.screenshot(path=str(ROOT / 'docs/story-mobile.png'), full_page=True)
        page.evaluate('window.__OPENING__.player.showCue(134, false)')
        assert page.locator('#passage').inner_text() == 'it was only meant for someone.'
        page.click('#next-passage')
        assert page.locator('#opening-end').is_visible()
        assert page.evaluate('window.__OPENING__.getState().state') == 'finished'
        passed('The exact final sentence is retained and the end card waits for the user')
        page.screenshot(path=str(ROOT / 'docs/ending-mobile.png'), full_page=True)
        page.click('#replay-opening')
        assert page.evaluate('window.__OPENING__.getState().index') == 0
        passed('Replay begins at the first paragraph')
        page.emulate_media(reduced_motion='reduce')
        page.wait_for_timeout(100)
        assert page.evaluate('window.__OPENING__.getState().reduced')
        page.evaluate('window.__OPENING__.player.showCue(2, false)')
        assert page.locator('.passage-word').evaluate_all('(els) => els.every(e => getComputedStyle(e).transform === "none" || getComputedStyle(e).transform === "matrix(1, 0, 0, 1, 0, 0)")')
        passed('Reduced motion removes text travel without removing content')
        page.emulate_media(reduced_motion='no-preference')
        page.set_viewport_size({'width': 1440, 'height': 960})
        page.evaluate('window.__OPENING__.player.frameSamples=[]; window.__OPENING__.player.showCue(2, true)')
        page.wait_for_timeout(4000)
        stats = page.evaluate('''() => {
          const a=window.__OPENING__.player.frameSamples.filter(x=>x>0).sort((a,b)=>a-b);
          const avg=a.reduce((a,b)=>a+b,0)/a.length;
          return {samples:a.length, meanFrameMs:avg, medianFrameMs:a[Math.floor(a.length/2)],
                  p95FrameMs:a[Math.floor(a.length*.95)], approximateCallbackFPS:1000/avg};
        }''')
        page.evaluate('window.__OPENING__.player.pause()')
        page.evaluate('''() => {
          const p=window.__OPENING__.player;
          const originalShow=p.showCue.bind(p);
          window.__OPENING_SEQUENCE__=[];
          p.showCue=(i,playing)=>{ if(i<135) window.__OPENING_SEQUENCE__.push(i); return originalShow(i,playing); };
          document.querySelector('#sound-choice').checked=false;
          p.speed=100;
          p.begin(0);
        }''')
        page.wait_for_function("window.__OPENING__.getState().state === 'finished'", timeout=20000)
        assert page.evaluate('window.__OPENING_SEQUENCE__') == list(range(135))
        passed('Accelerated automatic playback visits every paragraph in order before ending')
        assert not errors, errors
        passed('No uncaught page errors during these native UI checks')
        report = {'engine': state['engine'], 'testMode': 'served-url' if url else 'in-memory native bundle',
                  'tests': results, 'errors': errors, 'frameCallbackSample': stats,
                  'limitations': 'Not an iPhone/Safari test. Frame callbacks are not GPU-presented frame measurements. GSAP only verified when --require-gsap succeeds.'}
        (ROOT / 'docs/browser-test-results.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(stats, indent=2))
        browser.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--url')
    parser.add_argument('--require-gsap', action='store_true')
    args = parser.parse_args()
    if args.require_gsap and not args.url:
        parser.error('--require-gsap requires --url')
    run(args.url, args.require_gsap)
