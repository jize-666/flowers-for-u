import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { OPENING } from '../static/js/opening-config.js';
import { SYNOPSIS, PARAGRAPHS, CHAPTERS } from '../static/js/opening-content.js';
import { cueTiming } from '../static/js/opening-motion.js';

const original = readFileSync(new URL('../docs/synopsis-original.txt', import.meta.url), 'utf8').replace(/\n$/, '');
const manifest = JSON.parse(readFileSync(new URL('../docs/content-manifest.json', import.meta.url), 'utf8'));

test('Narrative exactly matches the canonical UTF-8 copy', () => assert.equal(SYNOPSIS, original));
test('Every paragraph reassembles without loss or rewrite', () => assert.equal(PARAGRAPHS.join('\n\n'), original));
test('Content hash and counts are stable', () => {
  assert.equal(createHash('sha256').update(SYNOPSIS).digest('hex'), manifest.utf8_sha256);
  assert.equal(PARAGRAPHS.length, 135);
  assert.equal(SYNOPSIS.split(/\s+/u).length, 1053);
});
test('Ending and the continuation after the user instruction are present', () => {
  assert.equal(PARAGRAPHS[90], 'Or why he suddenly cared so much about making it feel right.');
  assert.equal(PARAGRAPHS[91], 'And he certainly never said who it was meant for.');
  assert.equal(PARAGRAPHS.at(-1), 'it was only meant for someone.');
});
test('Chapters are sorted, unique and start at existing paragraphs', () => {
  assert.equal(CHAPTERS.length, 8);
  assert.equal(CHAPTERS[0].start, 0);
  assert.equal(new Set(CHAPTERS.map(c => c.start)).size, 8);
  CHAPTERS.forEach((c, i) => { assert.ok(PARAGRAPHS[c.start]); if (i) assert.ok(c.start > CHAPTERS[i - 1].start); });
});
test('Every passage has enough time for the reveal before its exit', () => {
  for (const text of PARAGRAPHS) {
    const timing = cueTiming(text, OPENING);
    assert.ok(timing.duration > timing.exitAt);
    assert.ok(timing.hold >= OPENING.minimumReadSeconds);
    assert.ok(timing.exitAt >= timing.reveal);
    assert.ok(Number.isFinite(timing.duration));
  }
});
test('Long paragraphs receive more reading time', () => {
  assert.ok(cueTiming(PARAGRAPHS[2], OPENING).duration > cueTiming('Code.', OPENING).duration);
});
test('Chapter pauses and the final hold extend rather than truncate text', () => {
  const normal = cueTiming('For you.', OPENING);
  const extra = cueTiming('For you.', OPENING, true, true);
  assert.ok(Math.abs(extra.duration - normal.duration - OPENING.chapterPauseSeconds - OPENING.finalHoldSeconds) < .00001);
});
test('Integration entry bypass does not navigate to the prologue again', () => assert.equal(OPENING.gardenUrl, '/?garden=1'));
