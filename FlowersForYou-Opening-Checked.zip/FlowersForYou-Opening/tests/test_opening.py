from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
import wave
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('integration', ROOT / 'tools/integrate_opening.py')
integration = importlib.util.module_from_spec(spec)
spec.loader.exec_module(integration)


class Tags(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.sources = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if tag in ('script', 'img') and attrs.get('src', '').startswith('/static/'):
            self.sources.append(attrs['src'])
        if tag == 'link' and attrs.get('href', '').startswith('/static/'):
            self.sources.append(attrs['href'])


class OpeningTests(unittest.TestCase):
    def test_html_ids_and_assets(self):
        parser = Tags()
        parser.feed((ROOT / 'templates/opening.html').read_text())
        self.assertEqual(len(parser.ids), len(set(parser.ids)))
        for path in parser.sources:
            self.assertTrue((ROOT / path.lstrip('/')).is_file(), path)

    def test_content_hash(self):
        original = (ROOT / 'docs/synopsis-original.txt').read_text().rstrip('\n')
        manifest = json.loads((ROOT / 'docs/content-manifest.json').read_text())
        self.assertEqual(hashlib.sha256(original.encode()).hexdigest(), manifest['utf8_sha256'])
        self.assertEqual((ROOT / 'static/text/opening-story.txt').read_text().rstrip('\n'), original)

    def test_wav_master(self):
        with wave.open(str(ROOT / 'static/audio/opening-warmth.wav')) as audio:
            self.assertEqual(audio.getnchannels(), 2)
            self.assertEqual(audio.getframerate(), 24000)
            self.assertEqual(audio.getnframes() / audio.getframerate(), 64)

    def test_no_bundled_fonts(self):
        self.assertFalse([p for p in ROOT.rglob('*') if p.suffix in ('.woff', '.woff2', '.ttf', '.otf')])

    def test_simple_integration(self):
        original = 'from flask import Flask\napp = Flask(__name__)\n@app.get("/")\ndef garden():\n    return "original"\n'
        patched = integration.patched_app(original)
        ast.parse(patched)
        self.assertIn('install_opening(app)', patched)
        self.assertIn('return "original"', patched)
        self.assertEqual(integration.patched_app(patched), patched)

    def test_factory_integration(self):
        original = 'from flask import Flask\ndef create_app():\n    app = Flask(__name__)\n    return app\n'
        patched = integration.patched_app(original)
        ast.parse(patched)
        self.assertIn('    install_opening(app)\n    return app', patched)

    def test_ambiguous_integration_rejected(self):
        with self.assertRaises(ValueError):
            integration.patched_app('app = Flask("one")\nother = Flask("two")')

    def test_installer_preserves_garden_and_backups(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            app = 'from flask import Flask\napp = Flask(__name__)\n'
            (target / 'app.py').write_text(app)
            (target / 'static/js').mkdir(parents=True)
            (target / 'static/js/config.js').write_text('DO NOT CHANGE THIS')
            command = [sys.executable, str(ROOT / 'tools/integrate_opening.py'), '--target', str(target)]
            subprocess.run(command, check=True, capture_output=True)
            self.assertEqual((target / 'app.py').read_text(), app)
            subprocess.run(command + ['--apply'], check=True, capture_output=True)
            self.assertEqual((target / 'static/js/config.js').read_text(), 'DO NOT CHANGE THIS')
            backups = list(target.glob('app.py.before-opening-*.bak'))
            self.assertEqual(len(backups), 1)
            self.assertEqual(backups[0].read_text(), app)
            self.assertTrue((target / 'templates/opening.html').is_file())


if __name__ == '__main__':
    unittest.main()
