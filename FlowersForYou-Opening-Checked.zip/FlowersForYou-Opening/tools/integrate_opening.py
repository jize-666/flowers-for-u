from pathlib import Path
from datetime import datetime, timezone
import argparse
import ast
import shutil

SOURCE = Path(__file__).resolve().parents[1]


def patched_app(text):
    tree = ast.parse(text)
    if any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
           and node.func.id == 'install_opening' for node in ast.walk(tree)):
        return text
    candidates = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        value = node.value
        if not isinstance(value, ast.Call):
            continue
        name = getattr(value.func, 'id', None) or getattr(value.func, 'attr', None)
        if name != 'Flask':
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if len(targets) == 1 and isinstance(targets[0], ast.Name):
            candidates.append((node, targets[0].id))
    if len(candidates) != 1:
        raise ValueError('Automatic integration needs exactly one named Flask(...) assignment. Use the two-line manual integration in OPENING_README.md instead.')
    node, app_name = candidates[0]
    lines = text.splitlines(keepends=True)
    indent = ' ' * node.col_offset
    insertion = f'{indent}from opening_routes import install_opening\n{indent}install_opening({app_name})\n'
    if not lines[node.end_lineno - 1].endswith('\n'):
        lines[node.end_lineno - 1] += '\n'
    lines.insert(node.end_lineno, insertion)
    result = ''.join(lines)
    ast.parse(result)
    return result


def file_plan(target):
    files = [(SOURCE / 'opening_routes.py', target / 'opening_routes.py')]
    files.append((SOURCE / 'templates/opening.html', target / 'templates/opening.html'))
    for folder in ['static/css', 'static/js', 'static/audio', 'static/icons', 'static/textures', 'static/text']:
        files.extend((item, target / item.relative_to(SOURCE)) for item in sorted((SOURCE / folder).glob('opening*')) if item.is_file())
    for item in (SOURCE / 'static/vendor/opening-gsap').glob('*'):
        if item.is_file(): files.append((item, target / item.relative_to(SOURCE)))
    files.append((SOURCE / 'tools/install_opening_gsap.py', target / 'tools/install_opening_gsap.py'))
    files.append((SOURCE / 'tools/build_opening_assets.py', target / 'tools/build_opening_assets.py'))
    files.append((SOURCE / 'OPENING_README.md', target / 'docs/opening/OPENING_README.md'))
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--target', type=Path, required=True)
    parser.add_argument('--app', default='app.py')
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    target = args.target.resolve()
    app_path = target / args.app
    if not app_path.is_file():
        raise SystemExit(f'Not found: {app_path}. Nothing changed.')
    original = app_path.read_text(encoding='utf-8')
    try:
        updated = patched_app(original)
    except (ValueError, SyntaxError) as error:
        raise SystemExit(str(error))
    plan = file_plan(target)
    for source, destination in plan:
        if destination.exists() and source.read_bytes() != destination.read_bytes():
            raise SystemExit(f'Already exists with different contents: {destination}. Nothing changed. Back it up and update manually.')
    print(f'Target: {target}')
    print(f'Add {len(plan)} opening-only files. Existing garden HTML/CSS/JS stay untouched.')
    print('Patch Flask registration: ' + ('yes, with backup' if updated != original else 'already installed'))
    if not args.apply:
        print('Dry run only. Repeat with --apply to install.')
        return
    for source, destination in plan:
        destination.parent.mkdir(parents=True, exist_ok=True)
        if source.resolve() != destination.resolve(): shutil.copy2(source, destination)
    if updated != original:
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        backup = app_path.with_name(app_path.name + '.before-opening-' + stamp + '.bak')
        shutil.copy2(app_path, backup)
        pending = app_path.with_name(app_path.name + '.opening-tmp')
        pending.write_text(updated, encoding='utf-8')
        pending.replace(app_path)
        print('Backup: ' + str(backup))
    print('Installed. Restart Flask. Open /opening or /. Your garden remains at /?garden=1.')


if __name__ == '__main__':
    main()
