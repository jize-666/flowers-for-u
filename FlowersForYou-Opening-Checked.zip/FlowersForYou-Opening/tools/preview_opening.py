from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import argparse

ROOT = Path(__file__).resolve().parents[1]


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        url = urlsplit(self.path)
        if url.path in ('/', '/opening', '/opening/'):
            if url.path == '/' and parse_qs(url.query).get('garden') == ['1']:
                self.path = '/docs/garden-placeholder.html'
            else:
                self.path = '/templates/opening.html'
        elif not url.path.startswith(('/static/', '/docs/')):
            self.send_error(404)
            return
        super().do_GET()

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5000)
    parser.add_argument('--host', default='0.0.0.0')
    args = parser.parse_args()
    print(f'Opening preview on port {args.port}. This is not a production server.', flush=True)
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()
