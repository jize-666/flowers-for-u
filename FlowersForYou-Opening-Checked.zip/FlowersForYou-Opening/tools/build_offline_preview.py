from pathlib import Path
import base64
import re

ROOT = Path(__file__).resolve().parents[1]


def data_uri(path):
    suffix = path.suffix
    mime = {'.mp3': 'audio/mpeg', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.png': 'image/png', '.txt': 'text/plain'}[suffix]
    return f'data:{mime};base64,' + base64.b64encode(path.read_bytes()).decode('ascii')


def build(debug=False):
    html = (ROOT / 'templates/opening.html').read_text(encoding='utf-8')
    html = re.sub(r'\s*<link[^>]+(?:fonts\.googleapis|fonts\.gstatic)[^>]*>', '', html)
    css = (ROOT / 'static/css/opening.css').read_text(encoding='utf-8')
    for name in ['opening-paper.webp', 'opening-grain.png']:
        css = css.replace('/static/textures/' + name, data_uri(ROOT / 'static/textures' / name))
    html = html.replace('<link rel="stylesheet" href="/static/css/opening.css">', '<style>' + css + '</style>')
    html = html.replace('/static/icons/opening-mark.svg', data_uri(ROOT / 'static/icons/opening-mark.svg'))
    html = html.replace('/static/text/opening-story.txt', data_uri(ROOT / 'static/text/opening-story.txt'))
    code = ''
    for name in ['opening-config.js', 'opening-content.js', 'opening-motion.js', 'opening-audio.js', 'opening.js']:
        content = (ROOT / 'static/js' / name).read_text(encoding='utf-8')
        content = re.sub(r'^import .*?;\s*$', '', content, flags=re.M)
        content = re.sub(r'^export ', '', content, flags=re.M)
        code += content + '\n'
    code = code.replace('/static/audio/opening-warmth.mp3', data_uri(ROOT / 'static/audio/opening-warmth.mp3'))
    setup = 'window.__OPENING_NATIVE_ONLY__ = true; window.__OPENING_PREVIEW__ = true;'
    if debug:
        setup += 'window.__OPENING_DEBUG__ = true;'
    code = setup + '\n' + code
    code = code.replace('</script', '<\\/script')
    html = html.replace('<script type="module" src="/static/js/opening.js"></script>', '<script type="module">' + code + '</script>')
    return html


if __name__ == '__main__':
    target = ROOT / 'Opening-Preview-Offline.html'
    target.write_text(build(), encoding='utf-8')
    print(target)
