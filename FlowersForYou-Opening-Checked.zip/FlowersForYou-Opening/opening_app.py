import os
from flask import Flask
from opening_routes import install_opening

app = Flask(__name__)
install_opening(app)


@app.get('/')
def garden_placeholder():
    return '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Opening complete</title><body style="background:#0b100f;color:#eae2d1;font:20px/1.8 Georgia;max-width:600px;margin:15vh auto;padding:30px"><h1>The opening is complete.</h1><p>This standalone package contains the prologue. After integration, this link opens your existing 3D garden instead of this placeholder.</p><p><a style="color:#c6caa9" href="/opening">Return to the opening</a></p></body></html>'''


if __name__ == '__main__':
    app.run(host=os.getenv('HOST', '0.0.0.0'), port=int(os.getenv('PORT', '5000')), debug=False)
