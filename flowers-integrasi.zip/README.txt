FLOWERS — INTEGRASI GARDEN KE MULTIVERSE

Paket ini diterapkan pada project dari flowers-uji.txt.zip yang dikirim pengguna.
Ini paket perubahan, bukan project lengkap untuk dijalankan sendiri.

PEMASANGAN DI CODESPACES
1. Upload flowers-integrasi.zip ke folder utama flowers-for-u.
2. Dari terminal di folder utama:
   unzip flowers-integrasi.zip -d _integrasi
   node _integrasi/apply-integration.mjs
3. Installer memeriksa hash seluruh file yang akan diganti beserta dependency
   lokal. Jika ada perubahan sejak ZIP dibuat, installer berhenti sebelum
   menulis. File yang diganti dicadangkan ke _backup-integrasi-<waktu>.
   Menjalankan installer lagi aman; file yang sudah sesuai dilewati.
4. Jalankan npm test. Server Flask yang sedang berjalan tetap dapat melayani
   file statis baru. Muat ulang penuh halaman /?garden=1; tutup tab preview
   lama dan buka lagi bila browser masih menyimpan modul sebelumnya.
5. Jika server berhenti, jalankan python app.py seperti sebelumnya.

CARA MEMICU
Tunggu intro selesai dan surat tertutup. Izinkan kamera, aktifkan tombol sound,
dan tunggu kamera/tracker/resource/audio siap. Tampilkan telapak terbuka,
lalu kepalkan terus-menerus minimal satu detik. Collapse hanya commit sekali.
Alur: garden_intro -> garden_break -> void_fall -> multiverse_arrival ->
multiverse_interaction. Setelah arrival selesai, buka telapak kembali untuk
memulai interaksi multiverse.

Garden intro, surat terbuka, halaman tersembunyi, tracker belum siap, audio
belum siap, atau resource belum siap akan memblokir commit. Jika genggaman
terputus atau tracking hilang, ulangi telapak terbuka lalu kepalan.
Kegagalan kamera ditampilkan pada petunjuk; gesture tidak dipalsukan.
MediaPipe masih mengambil model dan runtime melalui internet.

ISI PERUBAHAN
- main.js menghubungkan tracking, collapse, void, arrival, multiverse dan audio.
- config.js mendapat pengaturan/budget fase baru. Nilai CONFIG lama, QUALITY
  lama, CONTENT dan FLOWERS dipastikan sama dengan ZIP pengguna.
- scene/audio/flowers/atmosphere mendapat dukungan transisi dan cleanup.
- CSS vignette menerima warna transisi dengan fallback warna garden semula.
- experience.js membatasi commit hanya ketika garden siap dijelajahi,
  surat tertutup, halaman terlihat dan instance belum dibuang.
- Tes fase baru disertakan; npm test menjalankan seluruh tests/*.test.js.
- Modul fitur yang sebelumnya sudah sama tidak ditulis ulang.
- Tidak ada commit, push, perubahan branch atau endpoint Python baru.

VERIFIKASI DI LINGKUNGAN PEMBUATAN PAKET
108 tes JavaScript lulus, 0 gagal, 0 dilewati. Timeline diuji dengan GSAP
3.13.0 asli dari vendor yang disertakan pengguna. Pemeriksaan sintaks lulus.
22 file terlindungi termasuk letter.js, interaction.js, bootstrap, template,
Flask dan aset terkait sama persis dengan unggahan pengguna. Semua import
relatif modul JS yang diperiksa tersedia. Installer diuji pemasangan,
pemasangan ulang, dan penolakan file yang berubah.
Log: payload/docs/integrasi/.

BELUM DIVERIFIKASI
Render WebGL/shader di browser nyata, kamera/MediaPipe nyata, kualitas dengar,
kontinuitas visual, FPS, dan memori GPU. Tes unit menggunakan mock untuk API
perangkat. Tidak ada klaim bebas bug atau jaminan 60 FPS. Audio transisi yang
tersedia menggunakan sintesis bawaan paket; kualitasnya perlu didengarkan.
