import { readFileSync, writeFileSync, existsSync, mkdirSync, copyFileSync, unlinkSync, lstatSync } from 'node:fs';
import { resolve, dirname, join, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const bundle = dirname(fileURLToPath(import.meta.url));
const root = process.cwd();
const manifest = JSON.parse(readFileSync(join(bundle, 'manifest.json'), 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const pathAt = (base, relative) => {
  const path = resolve(base, relative);
  if (!path.startsWith(resolve(base) + sep)) throw new Error('Path tidak valid: ' + relative);
  let cursor = path;
  while (cursor !== resolve(base)) {
    if (existsSync(cursor) && lstatSync(cursor).isSymbolicLink()) throw new Error('Symlink tidak didukung: ' + relative);
    cursor = dirname(cursor);
  }
  return path;
};

try {
  if (!existsSync(join(root, 'app.py')) || !existsSync(join(root, 'static/js/main.js'))) {
    throw new Error('Jalankan dari folder project flowers-for-u, bukan folder paket integrasi.');
  }
  const pending = [], conflicts = [];
  for (const entry of manifest.files) {
    const payload = pathAt(join(bundle, 'payload'), entry.path);
    const bytes = readFileSync(payload);
    if (hash(bytes) !== entry.after) throw new Error('Isi paket tidak cocok: ' + entry.path);
    const target = pathAt(root, entry.path);
    const actual = existsSync(target) ? hash(readFileSync(target)) : null;
    if (actual === entry.after) continue;
    if (actual !== entry.before) conflicts.push(entry.path);
    else pending.push({ ...entry, target, bytes });
  }
  for (const entry of manifest.dependencies) {
    const target = pathAt(root, entry.path);
    if (!existsSync(target) || hash(readFileSync(target)) !== entry.hash) conflicts.push(entry.path);
  }
  if (conflicts.length) throw new Error('File berubah sejak ZIP dikirim. Belum ada file yang ditulis:\n' + conflicts.join('\n'));
  if (!pending.length) {
    console.log('Integrasi sudah terpasang. Tidak ada perubahan tambahan.');
  } else {
    const backup = join(root, '_backup-integrasi-' + new Date().toISOString().replace(/[:.]/g, '-') + '-' + process.pid);
    mkdirSync(backup, { recursive: true });
    for (const entry of pending) {
      if (entry.before !== null) {
        const saved = pathAt(backup, entry.path);
        mkdirSync(dirname(saved), { recursive: true });
        copyFileSync(entry.target, saved);
      }
    }
    writeFileSync(join(backup, 'changes.json'), JSON.stringify(pending.map(({path,before,after}) => ({path,before,after})), null, 2));
    const written = [];
    try {
      for (const entry of pending) {
        mkdirSync(dirname(entry.target), { recursive: true });
        written.push(entry);
        writeFileSync(entry.target, entry.bytes);
      }
    } catch (error) {
      for (const entry of written.reverse()) {
        if (entry.before !== null) copyFileSync(pathAt(backup, entry.path), entry.target);
        else if (existsSync(entry.target)) unlinkSync(entry.target);
      }
      throw error;
    }
    console.log(`Integrasi terpasang: ${pending.length} file.\nCadangan: ${backup}\nBerikutnya: npm test, lalu buka ulang halaman garden.`);
  }
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
